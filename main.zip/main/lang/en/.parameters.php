<?
$MESS["S_ASK_QUESTION"] = "Text of the button \"Ask a question\"";
$MESS["S_ORDER_PRODUCT"] = "Text of the button \"Order product\"";
$MESS["T_CHARACTERISTICS"] = "Subheading text \"Characteristics\"";
$MESS["T_DOCS"] = "Subheading text \"Documents\"";
$MESS["T_GALLERY"] = "Gallery Subheading Text";
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display item date";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Display item name";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display detailed image";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Do not open social panel default bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "Key for for bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "Login for bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Used social. bookmarks and networks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Social Panel Component Template bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display announcement text";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Show social panel bookmarks";
$MESS["T_VIDEO"] = "Video subtitle text";
$MESS["USE_SHARE"] = "Show links on social networks";
?>