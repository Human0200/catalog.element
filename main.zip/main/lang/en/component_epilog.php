<?
$MESS["ARTICLE"] = "Art.";
$MESS["BRAND"] = "Brand:";
$MESS["BUTTON_IN_CART"] = "In the basket";
$MESS["BUTTON_TO_CART"] = "In garbage";
$MESS["DISCOUNT_PRICE"] = "Price without discount:";
$MESS["MORE_CHAR_BOTTOM"] = "All characteristics";
$MESS["MORE_TEXT"] = "We will contact you to clarify the form of payment and delivery method";
$MESS["MORE_TEXT_BOTTOM"] = "More details";
$MESS["SHARE_TEXT"] = "Share this";
$MESS["S_ASK_QUESTION"] = "Ask a Question";
$MESS["S_CHOISE_PRODUCT"] = "Select";
$MESS["S_ORDER_PRODUCT"] = "To order";
$MESS["S_ORDER_SERVISE"] = "Order a product";
$MESS["T_CHARACTERISTICS"] = "Characteristics";
$MESS["T_DESC"] = "Description";
$MESS["T_DEV"] = "Product developer";
$MESS["T_FAQ"] = "FAQ";
$MESS["T_DOCS"] = "Documents";
$MESS["T_ITEMS"] = "Products";
$MESS["T_SERVICES"] = "Services";
$MESS["T_VIDEO"] = "Video";
?>